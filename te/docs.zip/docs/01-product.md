# Product Overview

## Problem
- Users lack clear financial health view, follow random advice, feel overwhelmed, and drop off quickly.

## Solution
- Personal finance coach: collects profile/snapshot, bucketizes money, returns top 3 actions with monthly targets, explains "why" via deterministic rules + RAG, and tracks self-reported progress.

## Scope (MVP)
- Profile & snapshot (income, expenses, assets, debts, goals, risk).
- Metrics: net worth, savings rate, debt health, emergency fund status.
- Buckets: emergency, debt, short-term, long-term (optionally insurance).
- Plan: top 3 actions + monthly saving/invest targets; risk-adjusted allocation hints.
- Tracking: monthly self-report; on-track/behind status; nudges messaging (basic).
- Explainability: "Why this?" with cited snippet from a tiny curated corpus.

## Non-Goals (MVP)
- Real-time bank sync, trade execution, robo-advisory registration, tax filing, heavy agents.

## Success Metrics (early)
- ≥70% complete snapshot; ≥50% generate first plan; ≥30% follow ≥1 recommended action; ≥50% complete one monthly check-in.

## Audience (examples)
- Young professionals starting wealth, families juggling goals, first-time investors, overwhelmed users needing simple guidance.

## Positioning
- Trustworthy, deterministic math with explainable AI; simple language; action-first; privacy-first (self-reported data, optional uploads).
