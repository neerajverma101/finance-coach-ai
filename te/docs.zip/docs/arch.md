# Architecture (archived)

Content consolidated in `03-architecture.md`.

See `03-architecture.md` for current system overview, flows, data model summary, and rule engine outline.
