# 🎨 UI / UX & Design System

## Design Philosophy
- Simple
- Calm
- Trustworthy
- Finance without fear

Inspired by:
- Mint
- Notion
- Calm
- Google Material simplicity

---

## Core UI Principles
- One action per screen
- Plain language (no finance jargon)
- Visual buckets instead of tables
- Positive reinforcement

---

## Key Screens

### 1. Home / Dashboard
- Progress bar
- Current net worth
- “You are on track” message

### 2. Profile & Financial Snapshot
- Card-based inputs
- Optional advanced fields
- Save & continue anytime

### 3. Analysis Screen
- What’s working
- What needs fixing
- Priority warnings

### 4. Bucket View
- Emergency
- Debt
- Short-term goals
- Long-term wealth

Each bucket shows:
- Current amount
- Target
- Next action

### 5. Plan Screen
- Step-by-step actions
- Monthly targets
- Simple charts

### 6. Tracking & Nudges
- Monthly check-in
- “Did you invest this month?”
- Encouraging messages

---

## Design System

### Colors
- Primary: Calm Blue
- Success: Soft Green
- Warning: Amber
- Error: Muted Red

### Typography
- Headings: Inter / SF Pro
- Body: Simple sans-serif
- Numbers: Mono for clarity

### Components
- Cards
- Progress bars
- Sliders
- Chips (Low / Medium / High risk)

---

## UX Rule
If a user needs explanation → show tooltip  
If still confused → show “Why this?” (RAG explanation)
