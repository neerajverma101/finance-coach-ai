# AI / RAG Strategy

## Goals
- Explain recommendations with citations; keep AI minimal, auditable, and low-cost.

## Providers
- Primary: OpenRouter/Hugging Face (your keys) for generation + embeddings.
- Alternate: Gemini via Google AI Studio free tier; small local models as fallback.

## RAG Flow
1) Curated corpus (playbooks, FAQs, tax/reg snippets) ingested into Chroma/FAISS.
2) Query → embedding (OpenRouter/HF or Gemini) → top-k retrieve → optional rerank.
3) Prompt template (concise, cite sources) → LLM → return explanation with source IDs.
4) Log provenance (docs, scores, model version) in RecommendationLog.

## Agent/Tools
- Default deterministic flow; avoid broad agents.
- If needed, LangChain/LangGraph with narrowly scoped tools (calculator, parser, sandboxed backtest). MCP optional to expose these tools safely.

## Prompt Skeleton ("Why this?")
- Inputs: user profile summary, top action, retrieved snippets (id, text, source), rules version.
- Instructions: be concise, cite snippet IDs, avoid new advice, stay within provided context.

## Guardrails
- Tight top-k (e.g., 3–5), short context window, max tokens capped.
- Deny arbitrary web calls; no PII in logs; redact uploads; opt-in for file persistence.
