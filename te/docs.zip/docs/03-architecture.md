# Architecture

## System Overview
- Frontend: Streamlit app or Google AI Studio UI → Backend APIs.
- Backend: FastAPI/Streamlit for profile, analyzer, bucket/plan generation, RAG service.
- Data: SQLite (dev) / Supabase Postgres (free tier); storage local/Supabase; vector store Chroma/FAISS.
- LLM: OpenRouter/Hugging Face (preferred) or Gemini (GAI Studio) for generation/embeddings.

## Component Flow (LLD)
1) User submits profile/snapshot.
2) Profile service validates/stores.
3) Analyzer fetches data, computes metrics (net worth, savings rate, emergency months).
4) Rule engine applies priorities (emergency → debt → savings discipline) and allocates goals to buckets; risk-adjusts.
5) Planner emits top-3 actions + monthly targets; stores plan.
6) "Why this?" → RAG: embed query → Chroma/FAISS → rerank → prompt LLM → return cited explanation.

## Deployment (zero/minimal cost)
- Streamlit Community Cloud or GAI Studio for UI; Cloud Run/Render free for FastAPI/Streamlit backend.
- Supabase free tier for Postgres/Storage; Chroma/FAISS local container.
- Cron/Scheduler for nudges; SMTP free tier for email.

## Data Model (summary)
- User, UserProfile, FinancialSnapshot, Asset, Liability, Goal, Bucket, Plan, MonthlyProgress, RecommendationLog (audit). See schemas in prior db doc; keep portable via SQLModel/SQLAlchemy.

## Rule Engine (summary)
- Inputs: profile (risk), snapshot (income/expenses/savings), assets/liabilities, goals.
- Metrics: net worth, savings rate, emergency months.
- Rules:
  - Emergency fund <3mo → priority action.
  - High-interest debt >12% → priority action (avalanche/snowball).
  - Savings rate <20% → pay-yourself-first.
  - Goals: <3y → low-risk bucket; >5y → growth; else balanced.
  - Risk adjust allocations (low/med/high equity tilt).
- Output: top-3 actions, monthly saving/invest targets, bucket allocations.

## Interfaces
- API endpoints (FastAPI): snapshot ingest, plan generation, explain (RAG), health checks.
- Streamlit UI: forms for inputs, plan display, "Why this?" button.
