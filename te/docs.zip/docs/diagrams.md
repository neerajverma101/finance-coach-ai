# Diagrams (archived)

Key architecture and flows are summarized in `03-architecture.md`.

Add or regenerate diagrams there as needed.
