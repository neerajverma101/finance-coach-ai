# Pitch (archived)

Content consolidated in `01-product.md`.

Refer to `01-product.md` for the current product narrative and positioning.
