# Product Overview (archived)

Content consolidated in `01-product.md` and `02-plan.md`.

For the latest overview, scope, and positioning, see `01-product.md`.
