# Short Pitch (archived)

Content consolidated in `01-product.md`.

See `01-product.md` for the latest concise product story.
