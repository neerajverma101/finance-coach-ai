# Phases (archived)

Content consolidated in `02-plan.md` (Phases and Rapid Build slice).

See `02-plan.md` for current timelines and scope.
