# Rule Engine (archived)

Rule summary is in `03-architecture.md` (Rule Engine section): emergency fund, high-interest debt, savings discipline, goal allocation, risk adjustment, and top-3 action outputs.
