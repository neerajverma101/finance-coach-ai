# PRD (archived)

Content consolidated in `01-product.md` and `02-plan.md`.

See those files for current problem, goals, core features, and success metrics.
