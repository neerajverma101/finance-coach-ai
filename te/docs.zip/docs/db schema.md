# Database Schema (archived)

Schema summary is now in `03-architecture.md` (Data Model section) and uses ORM-friendly entities (SQLModel/SQLAlchemy) for portability (SQLite → Supabase Postgres).
