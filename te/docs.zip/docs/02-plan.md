# Delivery Plan

## Rapid Build (1–1.5 days, team of 6)
- Scope: single Streamlit/GAI Studio screen; deterministic rule engine; top-3 actions + monthly targets; one "Why this?" RAG call.
- Infra: in-memory/SQLite with lightweight ORM (SQLModel/SQLAlchemy) portable to Supabase; Chroma/FAISS; one provider path (OpenRouter/Hugging Face or Gemini); no auth/onboarding/notifications.
- Work split: rule engine + tests; minimal data models; tiny curated RAG corpus + one prompt; Streamlit UI; API/glue; lint/type/test harness.
- Definition of done: E2E flow runs locally; RAG returns cited snippet; `ruff`/`mypy`/`pytest` pass; `.env.example` documents keys.

## Phases (longer arc)
- **Phase 0 — Foundation:** define rules/playbooks, glossary, trusted sources, UX wires, compliance disclaimers.
- **Phase 1 — MVP:** profile/snapshot, metrics, bucketization, top-3 plan, monthly tracking, basic nudges, explainability.
- **Phase 2 — Explainable AI:** richer RAG content, finance Q&A, cited explanations.
- **Phase 3 — Power Users:** statement upload parsing, what-if scenarios, debt payoff comparisons, simple projections.
- **Phase 4 — Advanced:** ALM, rebalancing, advisor/broker integrations, compliance hardening.

## Tech Baseline (zero/minimal cost)
- Frontend: Streamlit (Python) or Google AI Studio app.
- Backend: FastAPI or Streamlit server functions.
- Data: SQLite (dev) → Supabase Postgres (free tier); Supabase Storage/local files for uploads.
- Vector store: Chroma/FAISS embedded.
- LLM/Embeddings: OpenRouter/Hugging Face (your keys) or Gemini via Google AI Studio free tier; small local models fallback.
- Orchestration: LangChain/LangGraph; MCP optional for exposing calculator/parser tools.
- Charts: Streamlit native/Plotly. Notifications: cron/scheduler + SMTP free tier.

## Quality Bar
- Tooling: `ruff`, `mypy`, `pytest`, `pytest-cov`, `pre-commit`.
- Health: `/healthz`, `/readyz`; structured logs; basic metrics.
- Security: env-based secrets; no PII logging; optional uploads with signed URLs; self-reported data by default.
