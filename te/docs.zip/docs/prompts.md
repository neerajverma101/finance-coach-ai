# Prompts (archived)

Prompt approach and template skeletons are in `04-ai-rag.md` ("Why this?" prompt).

Add prompt variants there as needed.
