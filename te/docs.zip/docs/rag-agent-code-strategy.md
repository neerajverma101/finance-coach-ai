# RAG / Agent Strategy (archived)

Content consolidated in `04-ai-rag.md`.

See `04-ai-rag.md` for provider choices (OpenRouter/Hugging Face/Gemini), RAG flow, guardrails, and agent/tool guidance.
